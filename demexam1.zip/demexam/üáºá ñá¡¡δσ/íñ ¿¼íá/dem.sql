drop database if exists dem;
create database dem;
use dem;
 
create table Conditionn(
ConditionnId integer primary key auto_increment,
requestConditionn varchar(40) not null);

create table Sort(
SortId integer primary key auto_increment,
SortText varchar(40) not null);

create table Commentt(
CommenttId integer primary key auto_increment,
message varchar(40) not null);

create table Roles(
RolesId integer primary key auto_increment,
RolesText varchar(40) not null);

create table Customer(
CustomerId integer primary key auto_increment,
FIO varchar(40) not null);

create table Worker(
WorkerId integer primary key auto_increment,
FIO varchar(40) not null);

create table usr (
userId integer primary key auto_increment,
login varchar(40) not null,
pass varchar(40) not null,
FIO varchar(40) not null,
phone varchar(40) not null,
RolesId integer  not null,
FOREIGN KEY (RolesId)  REFERENCES Roles (RolesId));

create table Orders (
OrdersId integer primary key auto_increment,
startDate date not null,
Models varchar(40) not null,
TrubleDescription varchar(40) not null,
ConditionnId integer  not null,
SortId integer  not null,
CustomerId integer  not null,
WorkerId integer,
CommenttID integer,
FOREIGN KEY (ConditionnId)  REFERENCES Conditionn (ConditionnId),
FOREIGN KEY (SortId)  REFERENCES Sort (SortId),
FOREIGN KEY (CustomerId)  REFERENCES Customer (CustomerId),
FOREIGN KEY (WorkerId)  REFERENCES Worker (WorkerId),
FOREIGN KEY (CommenttId)  REFERENCES Commentt (CommenttId));

insert into Sort(SortId,SortText) values (Null,'Компьютер');
insert into Sort(SortId,SortText) values (Null,'Смартфон');
insert into Sort(SortId,SortText) values (Null,'Пылесос');
insert into Sort(SortId,SortText) values (Null,'Дрель');

insert into Conditionn(ConditionnId,requestConditionn) values (Null,'В процессе');
insert into Conditionn(ConditionnId,requestConditionn) values (Null,'Готово');
insert into Conditionn(ConditionnId,requestConditionn) values (Null,'Не начато');

insert into Commentt(CommenttID,message) values (Null,'Будет сделано');
insert into Commentt(CommenttID,message) values (Null,'Постараемся');
insert into Commentt(CommenttID,message) values (Null,'Подумаем');

insert into Roles(RolesId,RolesText) values (Null,'Администратор');
insert into Roles(RolesId,RolesText) values (Null,'Технический специалист');
insert into Roles(RolesId,RolesText) values (Null,'Оператор');
insert into Roles(RolesId,RolesText) values (Null,'Заказчик');

insert into Customer(CustomerId,FIO) values (Null,'Тамадаев Рамазан Закирович');
insert into Customer(CustomerId,FIO) values (Null,'Омелянский Максим Тарасович');
insert into Customer(CustomerId,FIO) values (Null,'Панков Сергей Викторович');
insert into Customer(CustomerId,FIO) values (Null,'Хачатрян Тигран Араевич');

insert into Worker(WorkerId,FIO) values (Null,'Шалимов Станислав Эдуардович');
insert into Worker(WorkerId,FIO) values (Null,'Поздняков Станислав Сергеевич');
insert into Worker(WorkerId,FIO) values (Null,'Владимир Владимирович Путин');
insert into Worker(WorkerId,FIO) values (Null,'Кольцов Илья Андреевич');
insert into Worker(WorkerId,FIO) values (Null,'Леонтьев Валерий Петрович');
insert into Worker(WorkerId,FIO) values (Null,'Белоусов Виталий Леонидович');

insert into usr(userId,FIO,phone,login,pass,RolesId) values (Null,'Шалимов Станислав Эдуардович','88005554545','login1','pass1',1);
insert into usr(userId,FIO,phone,login,pass,RolesId) values (Null,'Поздняков Станислав Сергеевич','85245588585','login2','pass2',2);
insert into usr(userId,FIO,phone,login,pass,RolesId) values (Null,'Владимир Владимирович Путин','85214785221','login3','pass3',2);
insert into usr(userId,FIO,phone,login,pass,RolesId) values (Null,'Кольцов Илья Андреевич','852174145220','login4','pass4',3);
insert into usr(userId,FIO,phone,login,pass,RolesId) values (Null,'Леонтьев Валерий Петрович','85693652441','login5','pass5',3);
insert into usr(userId,FIO,phone,login,pass,RolesId) values (Null,'Белоусов Виталий Леонидович','85214785221','login6','pass6',4);


insert into Orders(OrdersId,startDate,Models,TrubleDescription,ConditionnId,SortId,WorkerId,CustomerId,CommenttID) values (Null, '2024-05-25','asus super pc','Не работает блок питания',1,1,2,2,1);
insert into Orders(OrdersId,startDate,Models,TrubleDescription,ConditionnId,SortId,WorkerId,CustomerId,CommenttID) values (Null, '2024-05-24','iphone 11 pro max','Не работает камера',1,2,3,3,2);
insert into Orders(OrdersId,startDate,Models,TrubleDescription,ConditionnId,SortId,WorkerId,CustomerId,CommenttID) values (Null, '2024-05-23','daison','Не работает насос',2,3,3,4,3);
insert into Orders(OrdersId,startDate,Models,TrubleDescription,ConditionnId,SortId,WorkerId,CustomerId,CommenttID) values (Null, '2024-05-22','super drill','Не работает ротор',3,4,Null,3,Null);

select * from Orders